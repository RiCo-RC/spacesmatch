import { Dimensions } from "react-native";

export const { width, height } = Dimensions.get("window");

export const VERSION = "0.0.1";

export const LEADERBOARD_MAX = 3;