

const PlayScreen = () => {};

export default PlayScreen;