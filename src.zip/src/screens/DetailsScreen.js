

const DetailsScreen = () => {};

export default DetailsScreen;