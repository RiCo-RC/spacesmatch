export { default as DetailsScreen } from "./DetailsScreen";
export { default as HomeScreen } from "./HomeScreen";
export { default as LeaderboardScreen } from "./LeaderboardScreen";
export { default as PlayScreen } from "./PlayScreen";
export { default as SplashScreen } from "./SplashScreen";